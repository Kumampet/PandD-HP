#include <iostream>
#include <string>
#include <algorithm>
#include <cctype>
using namespace std;

void toUpper(char &c) { c = toupper(c); }

int main()
{
	string str = "thIs IS a tESt";
	
	for_each(str.begin(), str.end(), toUpper);
	cout << str << endl; // THIS IS A TEST

	// �ä���������
	str.erase(remove(str.begin(), str.end(), ' '), str.end());
	cout << str << endl; // THISISATEST

	sort(str.begin(), str.end()); // ���祽����
	cout << str << endl; // AEHIISSSTTT
	sort(str.rbegin(), str.rend()); // �߽祽����
	cout << str << endl; // TTTSSSIIHEA

	return 0;
}
